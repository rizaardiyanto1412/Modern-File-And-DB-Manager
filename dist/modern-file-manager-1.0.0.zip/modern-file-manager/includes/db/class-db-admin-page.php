<?php
/**
 * DB manager admin page and launcher.
 *
 * @package ModernFileManager
 */

namespace ModernFileManager;

defined( 'ABSPATH' ) || exit;

/**
 * DB manager admin page.
 */
class DB_Admin_Page {
	/**
	 * Menu hook suffix.
	 *
	 * @var string
	 */
	private $hook_suffix = '';

	/**
	 * DB manager service.
	 *
	 * @var DB_Manager_Service
	 */
	private $db_service;

	/**
	 * Constructor.
	 *
	 * @param DB_Manager_Service $db_service DB service.
	 */
	public function __construct( DB_Manager_Service $db_service ) {
		$this->db_service = $db_service;
	}

	/**
	 * Initialize hooks.
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_post_mfm_db_manager_launch', array( $this, 'handle_db_launch' ) );
	}

	/**
	 * Register DB manager submenu.
	 *
	 * @return void
	 */
	public function register_menu() {
		$this->hook_suffix = add_submenu_page(
			'modern-file-manager',
			esc_html__( 'DB Manager', 'modern-file-manager' ),
			esc_html__( 'DB Manager', 'modern-file-manager' ),
			'manage_options',
			'modern-file-manager-db',
			array( $this, 'render_page' )
		);
	}

	/**
	 * Register DB manager settings.
	 *
	 * @return void
	 */
	public function register_settings() {
		register_setting(
			'mfm_db_settings',
			DB_Manager_Service::OPTION_ENABLED,
			array(
				'type'              => 'boolean',
				'sanitize_callback' => array( 'ModernFileManager\\DB_Manager_Service', 'sanitize_enabled' ),
				'default'           => true,
			)
		);

		register_setting(
			'mfm_db_settings',
			DB_Manager_Service::OPTION_READ_ONLY,
			array(
				'type'              => 'boolean',
				'sanitize_callback' => array( 'ModernFileManager\\DB_Manager_Service', 'sanitize_read_only' ),
				'default'           => false,
			)
		);

		register_setting(
			'mfm_db_settings',
			DB_Manager_Service::OPTION_LAUNCH_TTL,
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( 'ModernFileManager\\DB_Manager_Service', 'sanitize_launch_ttl' ),
				'default'           => 300,
			)
		);
	}

	/**
	 * Render DB manager page.
	 *
	 * @return void
	 */
	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access DB Manager.', 'modern-file-manager' ) );
		}

		$db_info      = $this->db_service->get_db_info();
		$environment  = $this->db_service->detect_environment();
		$launch_url   = $this->db_service->generate_launch_url();
		$is_enabled   = $this->db_service->is_enabled();
		$is_read_only = $this->db_service->is_read_only();
		$ttl          = $this->db_service->get_launch_ttl();
		?>
		<div class="wrap">
			<h1><?php echo esc_html__( 'DB Manager', 'modern-file-manager' ); ?></h1>
			<div style="max-width:980px;background:#fff;border:1px solid #d0d7e2;border-radius:10px;padding:16px 18px;margin:14px 0;">
				<p><strong><?php echo esc_html__( 'Warning:', 'modern-file-manager' ); ?></strong> <?php echo esc_html__( 'Database operations can permanently change or delete data. Use carefully.', 'modern-file-manager' ); ?></p>
				<p>
					<?php echo esc_html__( 'Environment:', 'modern-file-manager' ); ?> <strong><?php echo esc_html( $environment ); ?></strong>
					&nbsp;|&nbsp;
					<?php echo esc_html__( 'Database:', 'modern-file-manager' ); ?> <strong><?php echo esc_html( $db_info['name'] ); ?></strong>
					&nbsp;|&nbsp;
					<?php echo esc_html__( 'Host:', 'modern-file-manager' ); ?> <strong><?php echo esc_html( $db_info['host'] ); ?></strong>
					&nbsp;|&nbsp;
					<?php echo esc_html__( 'User:', 'modern-file-manager' ); ?> <strong><?php echo esc_html( $db_info['user'] ); ?></strong>
				</p>

				<?php if ( $is_enabled ) : ?>
					<p>
						<a class="button button-primary" href="<?php echo esc_url( $launch_url ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__( 'Open Adminer', 'modern-file-manager' ); ?></a>
						<span style="margin-left:10px;color:#63758b;">
							<?php
							/* translators: %d: DB manager launch token TTL in seconds. */
							$ttl_label = esc_html__( 'Launch token TTL: %d seconds', 'modern-file-manager' );
							echo esc_html( sprintf( $ttl_label, (int) $ttl ) );
							?>
						</span>
					</p>
					<p class="description"><?php echo esc_html__( 'Adminer opens in a new tab.', 'modern-file-manager' ); ?></p>
				<?php else : ?>
					<p><em><?php echo esc_html__( 'DB Manager is currently disabled. Enable it in settings below.', 'modern-file-manager' ); ?></em></p>
				<?php endif; ?>
			</div>

			<div style="max-width:980px;background:#fff;border:1px solid #d0d7e2;border-radius:10px;padding:16px 18px;">
				<h2><?php echo esc_html__( 'DB Manager Settings', 'modern-file-manager' ); ?></h2>
				<form method="post" action="options.php">
					<?php settings_fields( 'mfm_db_settings' ); ?>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><?php echo esc_html__( 'Enable DB Manager', 'modern-file-manager' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="<?php echo esc_attr( DB_Manager_Service::OPTION_ENABLED ); ?>" value="1" <?php checked( $is_enabled ); ?> />
									<?php echo esc_html__( 'Allow DB Manager access for administrators', 'modern-file-manager' ); ?>
								</label>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php echo esc_html__( 'Read-only Mode', 'modern-file-manager' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="<?php echo esc_attr( DB_Manager_Service::OPTION_READ_ONLY ); ?>" value="1" <?php checked( $is_read_only ); ?> />
									<?php echo esc_html__( 'Attempt to run DB manager in read-only mode', 'modern-file-manager' ); ?>
								</label>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php echo esc_html__( 'Launch Token TTL', 'modern-file-manager' ); ?></th>
							<td>
								<input type="number" min="60" max="3600" step="1" name="<?php echo esc_attr( DB_Manager_Service::OPTION_LAUNCH_TTL ); ?>" value="<?php echo esc_attr( (string) $ttl ); ?>" class="small-text" />
								<p class="description"><?php echo esc_html__( 'Token expiration in seconds (60-3600).', 'modern-file-manager' ); ?></p>
							</td>
						</tr>
					</table>
					<?php submit_button( __( 'Save DB Settings', 'modern-file-manager' ) ); ?>
				</form>
			</div>
		</div>
		<?php
	}

	/**
	 * Handle DB manager launch endpoint.
	 *
	 * @return void
	 */
	public function handle_db_launch() {
		if ( ! current_user_can( 'manage_options' ) ) {
			$this->db_service->log_event( 'launch blocked: insufficient capability' );
			wp_die( esc_html__( 'You do not have permission to access DB Manager.', 'modern-file-manager' ), 403 );
		}

		if ( ! $this->db_service->is_enabled() ) {
			$this->db_service->log_event( 'launch blocked: module disabled' );
			wp_die( esc_html__( 'DB Manager is disabled.', 'modern-file-manager' ), 403 );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- token verification is handled by DB_Manager_Service::validate_launch_request() when signed params are present.
		$request = wp_unslash( $_GET );
		if ( ! is_array( $request ) ) {
			wp_die( esc_html__( 'Invalid DB Manager request.', 'modern-file-manager' ), 403 );
		}

		$has_signed_params = isset( $request['ts'] ) || isset( $request['token'] ) || isset( $request['sig'] );
		$has_adminer_file  = isset( $request['file'] ) || isset( $request['script'] );
		$has_adminer_state = isset( $request['username'] ) || isset( $request['db'] ) || isset( $request['server'] );

		// Validate signature only on the initial launch handoff.
		if ( $has_signed_params && ! $has_adminer_file && ! $has_adminer_state && ! $this->db_service->validate_launch_request( $request ) ) {
			wp_die( esc_html__( 'Invalid or expired DB Manager launch token.', 'modern-file-manager' ), 403 );
		}

		require_once MFM_PLUGIN_DIR . 'includes/db/adminer-loader.php';
		exit;
	}
}
